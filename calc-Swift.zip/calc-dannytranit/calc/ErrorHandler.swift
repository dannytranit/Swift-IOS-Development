//
//  ErrorHandler.swift
//  test
//
//  Created by Dat Tran on 30/3/18.
//  Copyright © 2018 Dat Tran. All rights reserved.
//

import Foundation
enum MyError: Error {
    case DivisionByZero
    case InvalidUserInput(string: String)
}

