//
//  StringExtension.swift
//  test
//
//  Created by Dat Tran on 30/3/18.
//  Copyright © 2018 Dat Tran. All rights reserved.
//

import Foundation
extension String {
    var isOperator: Bool {
        get {
            return ("+-x/%" as NSString).contains(self)
        }
    }
    var isNumber: Bool {
        get {
            let chr = CharacterSet.decimalDigits.inverted
            return rangeOfCharacter(from: chr) == nil && !self.isEmpty
        }
    }
}
