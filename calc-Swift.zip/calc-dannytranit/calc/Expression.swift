//
//  Expression.swift
//  test
//
//  Created by Dat Tran on 30/3/18.
//  Copyright © 2018 Dat Tran. All rights reserved.
//

import Foundation
struct Expression {
    let strings : [String]
    init (_ strings: [String]) {
        self.strings = strings
    }
    // tokenise Expression into String and Operator and put in "terms" array
    func tokenise () -> tokenisedExpression {
        var terms : [Term] = []
        for string in strings {
            if string.isNumber {
                terms.append(Number(string))
            }
            else if string.isOperator {
                terms.append(Operator(string))
            }
            else  {
                try! handleInvalidInput(string)
            }
        }
        return tokenisedExpression (terms)
    }
    // Handle invalid input from users
    func handleInvalidInput (_ string : String) throws {
        throw MyError.InvalidUserInput (string: string)
    }
}
struct tokenisedExpression {
    var terms : [Term]
    init (_ terms: [Term]) {
        self.terms = terms
    }
    // Loop through terms array and calculate numbers based on operator precedence
    func evaluate () throws-> Int {
        var numbers: [Number] = []
        var operators: [Operator] = []
        for term in terms {
            if let num = term as? Number {
                numbers.append(num)
            }
            // calculate numbers with high precendce first
            if let op = term as? Operator {
                while !operators.isEmpty && (operators.last!.precedence >= op.precedence || operators.last!.precedence >= Operator.defaultPrecedence){
                    let num = operators.last!.calculate(numbers[numbers.count-2], numbers.popLast()!)
                    numbers.removeLast()
                    operators.removeLast()
                    numbers.append(num)
                }
                operators.append(op)
            }
          
        }
        // calculate the remaing numbers
        while !operators.isEmpty {
            let num = operators.last!.calculate(numbers[numbers.count-2], numbers.popLast()!)
            numbers.removeLast()
            operators.removeLast()
            numbers.append(num)
        }
       return numbers.popLast()!.int
    }

}

