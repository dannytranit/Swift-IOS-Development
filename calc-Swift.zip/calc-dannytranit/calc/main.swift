//
//  ErrorHandler.swift
//  test on Travis
//
//  Created by Dat Tran on 30/3/18.
//  Copyright © 2018 Dat Tran. All rights reserved.
///

import Foundation

var args = ProcessInfo.processInfo.arguments
args.removeFirst() // remove the name of the program
let strings = Formatter (args).formalise()
let tokensiedExpression = Expression (strings).tokenise()
let result = try tokensiedExpression.evaluate()
print (result)
