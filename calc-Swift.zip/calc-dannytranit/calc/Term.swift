//
//  Term.swift
//  test
//
//  Created by Dat Tran on 30/3/18.
//  Copyright © 2018 Dat Tran. All rights reserved.
//

import Foundation
class Term {
    let string : String
    init (_ str: String) {
        self.string = str
    }
}
