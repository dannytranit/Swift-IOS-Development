//
//  Token.swift
//  test
//
//  Created by Dat Tran on 30/3/18.
//  Copyright © 2018 Dat Tran. All rights reserved.
//

import Foundation
// Formalise expression before hanlding with arthmetic operations
struct Formatter  {
    var strs : [String]
    init (_ args : [String]) {
        self.strs = args
    }
    func formalise () -> [String] {
        var strings: [String] = []
        for str in strs {
            // if the str is a operator followed by a number, then add it to strings
            guard str.range(of: "^[+-]\\d+$", options: .regularExpression) != nil else {
                strings.append(str)
                continue
            }
            // seperate it to opertor and number and add them to strings
            let secondIndex = str.index(str.startIndex, offsetBy: 1)
            let op = String(str[str.startIndex])
            let num = String(str[secondIndex...])
            strings.append(op)
            strings.append(num)
        }
        for index in strings.indices {
            if (index < strings.count-1){
                let current = strings[index]
                let next = strings[index + 1]
                // Remove the blance
                if current.isEmpty {
                    strings.remove(at: index)
                }
                // Handle 2 operators which stand beside each other
                if (current == "+" && next == "+") || (current == "-" && next == "-") {
                    strings.replaceSubrange(Range(index...index+1), with: ["+"])
                    //print ("process same op-op")
                }
                if (current == "-" && next == "+") || (current == "+" && next == "-") {
                    strings.replaceSubrange(Range(index...index+1), with: ["-"])
                    //print ("process diff op-op")
                }
                if (current == "/" || current == "x") && (next == "-" || next == "+") {
                    let temp = next
                    strings.remove(at: index + 1)
                    strings.insert(temp, at: 0)
                }
            }
        }
        // Handle operators at beggining of expression
        if (strings.first == "+" || strings.first == "-"){
            strings.insert("0", at: 0) // add 0 before first element which is "-" or "+" operator
        }
        return strings
    }
    
}
