//
//  Number.swift
//  test
//
//  Created by Dat Tran on 30/3/18.
//  Copyright © 2018 Dat Tran. All rights reserved.
//

import Foundation
class Number : Term {
    let number : String
    let int: Int
    override init (_ num: String) {
        self.number = num
        self.int = Int(number)!
        super.init (number)
    }
    
}
