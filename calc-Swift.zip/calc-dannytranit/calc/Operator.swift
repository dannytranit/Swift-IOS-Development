//
//  Operator.swift
//  test
//
//  Created by Dat Tran on 30/3/18.
//  Copyright © 2018 Dat Tran. All rights reserved.
//

import Foundation
class Operator : Term {
    let op : String
    let precedence : Int
    static let defaultPrecedence = 2
    let opToPrecedence : [String : Int] = ["+": 1 , "-": 1, "x": 2, "/": 2, "%": 2]
    override init (_ oper: String) {
        self.op = oper
        self.precedence = opToPrecedence[op]!
        super.init(op)
    }
    // Handle maths
    func calculate (_ first : Number, _ second : Number) -> Number {
        switch op {
        case "+":
            return Number(String (first.int + second.int))
        case "-":
            return Number(String (first.int - second.int))
        case "x":
            return Number(String (first.int * second.int))
        case "/":
            return try! divide (first.int, second.int)
        case "%":
            return Number(String (first.int % second.int))
        default:
            return Number ("")
        }
    }
    // Handle errors of division by zero
    func divide(_ first: Int, _ second: Int) throws -> Number {
        guard second != 0 else {
            throw MyError.DivisionByZero
        }
        return Number(String(first / second))
    }
}

